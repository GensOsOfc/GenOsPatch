.class public final Lcom/genos/example/GenOsExample;
.super Ljava/lang/Object;

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static getMessage()Ljava/lang/String;
    .registers 1

    const-string v0, "GenOs Example"

    return-object v0
.end method
